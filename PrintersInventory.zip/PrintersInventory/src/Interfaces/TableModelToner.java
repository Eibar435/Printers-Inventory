/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interfaces;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Eibar V
 */
public class TableModelToner extends AbstractTableModel {
    
    private String[] columnas = {"Codigo", "Toner", "Stock"};
    private List<TonerBD> toner = new ArrayList<>();

    public TableModelToner(List<TonerBD> To) {
        this.toner = To;
    }
        
    
    @Override
    public int getRowCount() {
        return this.toner.size();
    }

    @Override
    public int getColumnCount() {
        return this.columnas.length;
    }

    @Override
    public Object getValueAt(int fila, int columna) {
        Object resp;
        
        switch(columna) {
            case 0:
                resp = this.toner.get(fila).getCodigo();
                break;
            case 1:
                resp = this.toner.get(fila).getToner();
                break;
            default:
                resp = this.toner.get(fila).getStock();
        }
        return resp;
    }
    
    @Override
    public String getColumnName(int colum) {
        return this.columnas[colum];
    }
    
    public void actualizarTabla() {
        fireTableDataChanged();
    }
    
    public TonerBD detalle(int fila) {
        return this.toner.get(fila);
    }
    
}