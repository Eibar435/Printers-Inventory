/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interfaces;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author Eibar V
 */
public class TableModelArea extends AbstractTableModel {
    
    private String[] columnas = {"Codigo", "Area", "Impresora", "Consumo", "FechaMensual"};
    private List<Area> area = new ArrayList<>();

    public TableModelArea(List<Area> Ar) {
        this.area = Ar;
    }
        
    
    @Override
    public int getRowCount() {
        return this.area.size();
    }

    @Override
    public int getColumnCount() {
        return this.columnas.length;
    }

    @Override
    public Object getValueAt(int fila, int columna) {
        Object resp;
        
        switch(columna) {
            case 0:
                resp = this.area.get(fila).getCodigo();
                break;
            case 1:
                resp = this.area.get(fila).getArea();
                break;
            case 2:
                resp = this.area.get(fila).getImpresora();
                break;
            case 3:
                resp = this.area.get(fila).getConsumo();
                break;
            default:
                resp = this.area.get(fila).getFecha();
        }
        return resp;
    }
    
    @Override
    public String getColumnName(int colum) {
        return this.columnas[colum];
    }
    
    public void actualizarTabla() {
        fireTableDataChanged();
    }
    
    public Area detalle(int fila) {
        return this.area.get(fila);
    }
    
}
