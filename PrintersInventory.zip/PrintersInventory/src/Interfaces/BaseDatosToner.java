/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interfaces;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author Eibar V
 */
public class BaseDatosToner {

    private HashMap<Integer, TonerBD> listaTonerBD = new HashMap<>();

    public BaseDatosToner() {
        
        this.listaTonerBD.put(1, new TonerBD(1, "CE255X", 2));
        this.listaTonerBD.put(2, new TonerBD(2, "CF281X", 4));
        this.listaTonerBD.put(3, new TonerBD(3, "90A", 2));
        this.listaTonerBD.put(4, new TonerBD(4, "CF287XC", 6));
        this.listaTonerBD.put(5, new TonerBD(5, "950 XL", 7));
        this.listaTonerBD.put(6, new TonerBD(6, "954 XL", 4));
        this.listaTonerBD.put(7, new TonerBD(7, "951 XL", 4));
        this.listaTonerBD.put(8, new TonerBD(8, "933 XL", 3));
        this.listaTonerBD.put(9, new TonerBD(9, "664 TRICOLOR", 1));
    }
    public List<TonerBD> getListaTonerBD() {
        return new ArrayList<>(this.listaTonerBD.values());
    }
    
    public void setListaTonerBD(HashMap<Integer, TonerBD> listaTonerBD) {
        this.listaTonerBD = listaTonerBD;
    }
    
    public boolean verificarToner(TonerBD toner) {
        return this.listaTonerBD.containsKey(toner.getCodigo());
    }
    
    public boolean verificarToner(String toner) {
        for (TonerBD t : this.listaTonerBD.values()) {
            if (toner.toLowerCase().equals(t.getToner().toLowerCase())) {
                return true;
            }
        }
        return false;
    }
    
    public int ultimoCodigo() {
        int codigo = 0;
        for (TonerBD t : this.listaTonerBD.values()) {
            codigo = t.getCodigo();
        }
        return codigo;
    } 
    public void actualizar(TonerBD t) {
        this.listaTonerBD.replace(t.getCodigo(), t);
    }
    public void agregar(TonerBD t) {
        this.listaTonerBD.put(t.getCodigo(), t);
    }
   
    public void borrar(TonerBD t) {
        this.listaTonerBD.remove(t.getCodigo());
    }
  
}
