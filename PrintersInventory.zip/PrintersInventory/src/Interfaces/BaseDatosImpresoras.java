/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interfaces;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author Eibar V
 */
public class BaseDatosImpresoras {
    private static final String M605 = "M605";
    private static final String P3015 = "P3015";

    private HashMap<Integer, Area> listaAreas = new HashMap<>();

    public BaseDatosImpresoras() {
        
        this.listaAreas.put(1, new Area(1, "Planeacion", M605, 65, "Enero"));
        this.listaAreas.put(2, new Area(2, "Planeacion 2", M605, 15, "Febrero"));
        this.listaAreas.put(3, new Area(3, "Produccion", M605, 33, "Febrero"));
        this.listaAreas.put(4, new Area(4, "Maquila", M605, 55, "Febrero"));
        this.listaAreas.put(5, new Area(5, "Materiales", M605, 42, "Marzo"));
        this.listaAreas.put(6, new Area(6, "Recibo", M605, 31, "Abril"));
        this.listaAreas.put(7, new Area(7, "Recursos Humanos", P3015, 41, "Mayo"));
        this.listaAreas.put(8, new Area(8, "Ingeneria", P3015, 55, "Mayo"));
        this.listaAreas.put(9, new Area(9, "ToolRoom", P3015, 80, "Octubre"));
        this.listaAreas.put(10, new Area(10, "Laboratorio", P3015, 10, "Noviembre"));
    }
    public List<Area> getListaAreas() {
        return new ArrayList<>(this.listaAreas.values());
    }
    
    public void setListaAreas(HashMap<Integer, Area> listaAreas) {
        this.listaAreas = listaAreas;
    }
    
    public boolean verificarImpresora(Area area) {
        return this.listaAreas.containsKey(area.getCodigo());
    }
    
    public boolean verificarImpresora(String area) {
        for (Area a : this.listaAreas.values()) {
            if (area.toLowerCase().equals(a.getArea().toLowerCase())) {
                return true;
            }
        }
        return false;
    }
    
    public int ultimoCodigo() {
        int codigo = 0;
        for (Area a : this.listaAreas.values()) {
            codigo = a.getCodigo();
        }
        return codigo;
    } 
    public void agregar(Area a) {
        this.listaAreas.put(a.getCodigo(), a);
    }
   
    public void borrar(Area a) {
        this.listaAreas.remove(a.getCodigo());
    }
  
}
